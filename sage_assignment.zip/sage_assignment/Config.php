<?php
class Config
{
    private static $instance = null;
    static $db_types;

    private function __construct($db) {
        $this->host = "localhost";
        $this->user  = "root";
        $this->pass = "";
        $this->db = $db;
    }
    public static function getConnect($db_types)
    {
        if (self::$instance == null) {
          self::$instance = new Config($db_types);
        }
        return self::$instance;
    }
}
?>
