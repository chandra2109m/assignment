<?php
	session_unset();
	require_once  'controller/StudentController.php';
	require_once  'controller/CourseController.php';
	require_once  'controller/StudentCourseRegistrationController.php';
    $student = new StudentController();
    $course = new CourseController();
    $student->studentHandler();
    $course->courseHandler();
    $studentCourseRegistrationController = new StudentCourseRegistrationController();
    $studentCourseRegistrationController->studentCourseHandler();
?>
