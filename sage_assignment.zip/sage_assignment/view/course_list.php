<div class="row">
    <div class="col-md-12">
        <div class="page-header clearfix">
            <h2 class="pull-left">Courses Details</h2>
            <a href="view/course_add.php" class="btn btn-success pull-right">Add New Course</a>
        </div>
        <?php
        if($result->num_rows > 0){
        echo "<table class='table table-bordered table-striped' id='courseId'>";
        echo "<thead>";
        echo "<tr>";
            echo "<th>#</th>";
            echo "<th>Course Name</th>";
            echo "<th>Course Details</th>";
            echo "<th>Action</th>";
            echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        while($row = mysqli_fetch_array($result)){
        echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['courseName'] . "</td>";
            echo "<td>" . $row['courseDetails'] . "</td>";
            echo "<td>";
                echo "<a href='index.php?act=courseUpdate&id=". $row['id'] ."' title='Update Record' data-toggle='tooltip'>Update<i class='fa fa-edit'></i></a>";
                echo "<a href='index.php?act=courseDelete&id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'
                onclick='myFunction()'>
                Delete<i class='fa fa-trash'></i></a>";
                echo "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
        } else{
        echo "<p class='lead'><em>No Course found.</em></p>";
        }
        ?>
        <script>
        function myFunction() {
          if (!confirm('Are you sure?')) { return false }
        }
        </script>
    </div>
</div>

