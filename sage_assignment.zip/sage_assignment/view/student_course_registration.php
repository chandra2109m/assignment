<?php
        require '../model/Student.php';
        require '../model/Course.php';
        session_start();
        $students=isset($_SESSION['studentForSubscription'])?unserialize($_SESSION['studentForSubscription']):'';
        $courses=isset($_SESSION['courseForSubscription'])?unserialize($_SESSION['courseForSubscription']):'';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Course Registration</title>
    <link rel="stylesheet" href="../libs/bootstrap.css">
    <script src="../libs/jquery.min.js"></script>
     <script src="../libs/bootstrap.js"></script>
</head>
<body>
    <div class="wrapper multi-field-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Student Course Registration</h2>
                    </div>
                    <form action="../index.php?act=subscribe" method="post" >
                        <div class="form-group col-lg-4">

                            <label>Student</label>
                            <select name="studentId" class="form-control" id="sel1">
                                <option value="">Select Student</option>
                                <?php
                                    foreach($students as $student){
                                ?>
                                <option value="<?php echo $student[0];?>"><?php echo $student[1].' '.$student[2]?></option>
                               <?php } ?>
                            </select>
                        </div>
                        <div class="form-group col-lg-4">
                            <label>Course</label>
                            <select name="courseSubscribeId[]" class="form-control text-two" id="sel1">
                                <option value="">Select Course</option>
                                <?php foreach($courses as $course){  ?>
                                    <option value="<?php echo $course[0];?>"><?php echo $course[1]?> </option>
                                 <?php } ?>
                             </select>
                              <div class="multi-fields">
                                <div class="multi-field">
                              </div>
                            </div>
                           <button type="button" class="add-field"><span class="bi bi-plus">+</span></button>
                            
                        </div>
                        <!-- Button -->
                        <div class="form-group col-lg-6">
                          <input type="submit" name="subscribe" class="btn btn-primary" value="submit">
                            <a href="../index.php" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
   $(document).ready(function () {

       $(document).on('change', '.text-two', function () { // when the attraction_OR_activity dropdown is selected
           var destination = $(this).parents('.multi-field');
           $(destination).find('.populated_attr_or_activity').html(''); // emptying the selections of 3rd dropdown list if there was any selections were made before.

           /* saving selected values in variables */
           var selected_attraction_or_activity = $(destination).find('.text-two :selected').val();
    $(destination).find('.populated_attr_or_activity').append('<option>' + t + '</option>');


       });

       /* ADD DESTINATION */
       $('.multi-field-wrapper').each(function () {
           var $wrapper = $('.multi-fields', this);
           var x = 1;
           $(".add-field", $(this)).click(function (e) {
               x++;
               $($wrapper).append('<div class="multi-field"><select name="courseSubscribeId[]" class="form-control text-two" id="sel1"><option value="">Select Course</option><?php foreach($courses as $course){  ?><option value="<?php echo $course[0];?>"><?php echo $course[1]?></option><?php } ?></select><a href="#" class="remove_field">Remove</a></div>');
           });

           $($wrapper).on("click", ".remove_field", function (e) { //user click on remove text
               e.preventDefault(); $(this).parent('div').remove(); x--;
           })
       });
   });

    </script>
</body>
</html>
