<?php
        require '../model/Student.php';
        session_start();
        $student=isset($_SESSION['sporttbl0'])?unserialize($_SESSION['sporttbl0']):new Student();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Student</title>
    <link rel="stylesheet" href="../libs/bootstrap.css">
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Update Student</h2>
                    </div>
                    <form action="../index.php?act=update" method="post" >
                    <input type="hidden" name="token" value="<?php echo $_SESSION['token'] ?? '' ?>">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="firstName" class="form-control" value="<?php echo $student->firstName; ?>" minlength="2" pattern ="[A-Za-z]{1,15}" required>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="lastName" class="form-control" value="<?php echo $student->lastName; ?>" minlength="2" pattern ="[A-Za-z]{1,15}" required>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $student->id; ?>"/>
                        <input type="submit" name="updatebtn" class="btn btn-primary" value="Submit">
                        <a href="../index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
