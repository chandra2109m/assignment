<div class="wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="page-header clearfix">
                    <h2 class="pull-left">Course Details</h2>
                    <a href="view/student_course_registration.php" class="btn btn-success pull-right">Subscribe Student To Course</a>
                </div>
                <?php if(count($data) > 0){
                echo "<table class='table table-bordered table-striped' id='report'>";
                echo "<thead>";
                echo "<tr>";
                    echo "<th>Student Name</th>";
                    echo "<th>Course Name</th>";
                    echo "</tr>";
                echo "</thead>";
                echo "<tbody>";
                echo "<tr>";
                foreach($data as $val){
                    echo "<td>" . Ucfirst($val['firstName'] .' '.$val['lastName']) ."</td>";
                    echo "<td>" . Ucfirst($val['courseName']) . "</td>";
                    echo "</tr>";
                }
                echo "</tbody>";
                echo "</table>";
                } else{
                echo "<p class='lead'><em>No Report found.</em></p>";
                }
                ?>
            </div>
        </div>
    </div>
 </div>
 </body>
</html>
