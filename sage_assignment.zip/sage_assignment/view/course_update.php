<?php
        require '../model/Course.php';
         session_start();
         $course=isset($_SESSION['sporttbl0'])?unserialize($_SESSION['sporttbl0']):new Course();
         $error = !empty($_SESSION['errorOnUpdate']) ? $_SESSION['errorOnUpdate'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Course Update</title>
    <link rel="stylesheet" href="../libs/bootstrap.css">
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Update Course</h2>
                    </div>
                    <p style="color:red"><?php echo $error; ?></p>
                    <form action="../index.php?act=courseUpdate" method="post" >
                        <div class="form-group">
                            <label>Course Name</label>
                            <input type="text" name="courseName" class="form-control" value="<?php echo $course->courseName; ?>">
                        </div>
                        <div class="form-group">
                            <label>Course Details</label>
                            <input type="text" name="courseDetails" class="form-control" value="<?php echo $course->courseDetails; ?> ">
                        </div>
                        <input type="hidden" name="id" value="<?php echo $course->id; ?>"/>
                        <input type="submit" name="updatebtn" class="btn btn-primary" value="Submit">
                        <a href="../index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
