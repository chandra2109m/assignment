<?php
        require '../model/Course.php';
        $course=new Course();
        session_start();
        $error = !empty($_SESSION['error']) ? $_SESSION['error'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Course</title>
     <link rel="stylesheet" href="../libs/bootstrap.css">
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Add Course</h2>
                    </div>
                    <p style="color:red"><?php echo $error; ?></p>
                    <form action="../index.php?act=courseAdd" method="post" >
                        <div class="form-group">
                            <label>Course Name</label>
                            <input type="text" name="courseName" class="form-control" value="" minlength="2" required>
                        </div>
                        <div class="form-group">
                            <label>Course Details</label>
                            <textarea name="courseDetails" class="form-control" value="" rows="4" cols="50" required></textarea>
                        </div>
                        <input type="submit" name="addbtn" class="btn btn-primary" value="Submit">
                        <a href="../index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
