<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="~/../libs/fontawesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" href="~/../libs/bootstrap.css">
    <script src="~/../libs/jquery.min.js"></script>
    <script src="~/../libs/bootstrap.js"></script>
    <script src="~/../libs/common.js"></script>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h2 class="pull-left">Students Details</h2>
                        <a href="view/student_add.php" class="btn btn-success pull-right">Add New Student</a>
                    </div>
                    <h2>Student Registration</h2>
                    <?php
                        if($result->num_rows > 0){
                    echo "<table class='table table-bordered table-striped ' id='data'>";
                    echo "<thead>";
                    echo "<tr>";
                        echo "<th>#</th>";
                        echo "<th>First Name</th>";
                        echo "<th>Last Name</th>";
                        echo "<th>Action</th>";
                        echo "</tr>";
                    echo "</thead>";
                    echo "<tbody>";
                    while($row = mysqli_fetch_array($result)){
                    echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['firstName'] . "</td>";
                        echo "<td>" . $row['lastName'] . "</td>";
                        echo "<td>";
                            echo "<a href='index.php?act=update&id=". $row['id'] ."' title='Update Record' data-toggle='tooltip'>Update<i class='fa fa-edit'></i></a>";
                            echo "<a href='index.php?act=delete&id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'
                            onclick='myFunction()'>
                            Delete<i class='fa fa-trash'></i></a>";
                            echo "</td>";
                        echo "</tr>";
                    }
                    echo "</tbody>";
                    echo "</table>";
                    // Free result set
                    mysqli_free_result($result);
                    } else{
                    echo "<p class='lead'><em>No student found.</em></p>";
                    }?>
                </div>
            </div>
        </div>
    </div>
