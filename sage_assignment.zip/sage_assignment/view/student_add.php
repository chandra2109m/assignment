<?php
        require '../model/Student.php';
        $student=new Student();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Student</title>
    <link rel="stylesheet" href="../libs/bootstrap.css">
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Add Student</h2>
                    </div>
                    <form action="../index.php?act=add" method="post" >
                        <div class="form-group">
                            <input type="hidden" name="token" value="<?php echo $_SESSION['token'] ?? '' ?>">
                            <label>First Name</label>
                            <input type="text" name="firstName" class="form-control" value="" pattern ="[A-Za-z]{1,15}" minlength = 2 required>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input name="lastName" class="form-control" value="" pattern ="[A-Za-z]{1,15}" minlength = 2 required>
                        </div>
                        <div class="form-group">
                            <label>DOB</label>
                            <input type ="date" name="dob" class="form-control" value="2018-07-22" required>
                        </div>
                        <div class="form-group">
                            <label>Contact No</label>
                            <input name="contactNo" type="tel" class="form-control" value="" pattern="[789][0-9]{9}" required oninput="check(this)">
                        </div>
                        <input type="submit" name="addbtn" class="btn btn-primary" value="Submit">
                        <a href="../index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
