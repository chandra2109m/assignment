<?php

class Course
{
    // table fields
    public $id;
    public $courseName;
    public $courseDetails;

    // constructor set default value
    function __construct()
    {
        $id=0;$courseName=$courseDetails="";
    }
}

?>
