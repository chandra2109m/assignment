<?php

class Student
{
    // table fields
    public $id;
    public $firstName;
    public $lastName;
    public $dob;
    public $contactNo;
    public $courseSubscribeId;

    // constructor set default value
    function __construct()
    {
        $id=$courseSubscribeId=0;$firstName=$lastName=$dob=$contactNo="";
    }
}

?>
