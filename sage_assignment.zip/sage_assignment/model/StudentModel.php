<?php

class StudentModel
{
    // set database config for mysql
    function __construct($conn) {
        $this->host = $conn->host;
        $this->user = $conn->user;
        $this->pass =  $conn->pass;
        $this->db = $conn->db;
    }
    // open mysql data base
    public function open_db() {
        $this->condb=new mysqli($this->host,$this->user,$this->pass,$this->db);
        if ($this->condb->connect_error) {
            die("Erron in connection: " . $this->condb->connect_error);
        }
    }
    // close database
    public function close_db() {
        $this->condb->close();
    }
    // insert
    public function insertStudent($obj) {
        try {
            $this->open_db();
            $query=$this->condb->prepare("INSERT INTO students (firstName,lastName,dob,contactNo,courseSubscribeId)
            VALUES (?, ?, ?, ?, ?)");
            $query->bind_param("sssss",$obj->firstName,$obj->lastName,$obj->dob,$obj->contactNo,$obj->courseSubscribeId);
            $query->execute();
            $res= $query->get_result();
            $last_id=$this->condb->insert_id;
            $query->close();
            $this->close_db();
            return $last_id;
        } catch (Exception $e) {
            $this->close_db();
            throw $e;
        }
    }
        //update
    public function updateStudent($obj, $courseSubscribeId=null,$id=null)
    {
        try {
            $this->open_db();
            if($courseSubscribeId) {
                $query=$this->condb->prepare("UPDATE students SET courseSubscribeId=? WHERE id=?");
                $query->bind_param("si", $courseSubscribeId,$id);
            } else {
                $query=$this->condb->prepare("UPDATE students SET firstName=?,lastName=? WHERE id=?");
                $query->bind_param("ssi", $obj->firstName,$obj->lastName,$obj->id);
            }
            $query->execute();
            $res=$query->get_result();
            $query->close();
            $this->close_db();
            return true;
        } catch (Exception $e) {
            $this->close_db();
            throw $e;
        }
    }

         // delete Student data
    public function deleteStudent($id) {
        try {
            $this->open_db();
            $query=$this->condb->prepare("DELETE FROM students WHERE id=?");
            $query->bind_param("i",$id);
            $query->execute();
            $res=$query->get_result();
            $query->close();
            $this->close_db();
            return true;
        } catch (Exception $e) {
            $this->closeDb();
            throw $e;
        }

    }

    // get student detail
    public function getStudent($id) {
        try {
            $this->open_db();
            if($id>0) {
                $query=$this->condb->prepare("SELECT * FROM students WHERE id=?");
                $query->bind_param("i",$id);
            } else {
                $query=$this->condb->prepare("SELECT * FROM students");
            }

            $query->execute();
            $res=$query->get_result();
            $query->close();
            $this->close_db();
            return $res;
        } catch(Exception $e) {
            $this->close_db();
            throw $e;
        }

    }

    // get student detail
   public function getSubscribeData()
   {
       try {
           $courses = [];
           $data = [];
           $this->open_db();
           $query=$this->condb->prepare("SELECT firstName,lastName,courseSubscribeId FROM students ");
           $query->execute();
           $res=$query->get_result();
           if ($res->num_rows > 0) {
               $i = 0;
               while ($row = mysqli_fetch_array($res)) {
                   if (isset($row["courseSubscribeId"]) && !empty($row["courseSubscribeId"])) {
                       $courseSubscribeId = $row["courseSubscribeId"];
                       $queryCourse=$this->condb->prepare("SELECT courseName FROM courses where id IN ($courseSubscribeId)");
                       $queryCourse->execute();
                       $result=$queryCourse->get_result();
                       if ($result->num_rows > 0) {
                           while ($courseData = mysqli_fetch_array($result)) {
                               array_push($courses,$courseData["courseName"]);
                           }
                       }
                       $data[$i]["courseName"] =  implode(",",$courses);
                       $data[$i]["firstName"] = $row["firstName"];
                       $data[$i]["lastName"] = $row["lastName"];
                       $i++;
                   }
               }
           }
           $query->close();
           $this->close_db();
           return $data;
       } catch(Exception $e) {
           $this->close_db();
           throw $e;
       }

   }
}

?>
