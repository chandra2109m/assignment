<?php

class CourseModel
{
    // set database config for mysql
    function __construct($conn) {
        $this->host = $conn->host;
        $this->user = $conn->user;
        $this->pass =  $conn->pass;
        $this->db = $conn->db;
    }
    // open mysql data base
    public function open_db() {
        $this->condb=new mysqli($this->host,$this->user,$this->pass,$this->db);
        if ($this->condb->connect_error) {
            die("Erron in connection: " . $this->condb->connect_error);
        }
    }
    // close database
    public function close_db() {
        $this->condb->close();
    }
    // insert
    public function insertCourse($obj) {
        try {
            $this->open_db();
            $query=$this->condb->prepare("INSERT INTO courses (courseName,courseDetails)
            VALUES (?, ?)");
            $query->bind_param("ss",$obj->courseName,$obj->courseDetails);
            $query->execute();
            $res= $query->get_result();
            $last_id=$this->condb->insert_id;
            $query->close();
            $this->close_db();
            return $last_id;
        } catch (Exception $e) {
            $this->close_db();
            throw $e;
        }
    }
        //update
    public function updateCourse($obj)
    {
        try {
            $this->open_db();
            $query=$this->condb->prepare("UPDATE courses SET courseName=?,courseDetails=? WHERE id=?");
            $query->bind_param("ssi", $obj->courseName,$obj->courseDetails,$obj->id);
            $query->execute();
            $res=$query->get_result();
            $query->close();
            $this->close_db();
            return true;
        } catch (Exception $e) {
            $this->close_db();
            throw $e;
        }
    }

         // delete Student data
    public function deleteCourse($id)
    {
        try {
            $this->open_db();
            $query=$this->condb->prepare("DELETE FROM courses WHERE id=?");
            $query->bind_param("i",$id);
            $query->execute();
            $res=$query->get_result();
            $query->close();
            $this->close_db();
            return true;
        } catch (Exception $e) {
            $this->closeDb();
            throw $e;
        }

    }

    // get student detail
    public function getCourse($id,$courseName = null) {
        try {
            $this->open_db();
            if($id>0) {
                $query=$this->condb->prepare("SELECT * FROM courses WHERE id=?");
                $query->bind_param("i",$id);
            } else if(!empty($courseName)){
              $query=$this->condb->prepare("SELECT * FROM courses WHERE courseName=?");
              $query->bind_param("s",$courseName);
            }else {
                $query=$this->condb->prepare("SELECT * FROM courses");
            }

            $query->execute();
            $res=$query->get_result();
            $query->close();
            $this->close_db();
            return $res;
        }
        catch(Exception $e) {
            $this->close_db();
            throw $e;
        }

    }
}

?>
