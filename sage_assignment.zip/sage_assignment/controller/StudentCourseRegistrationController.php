<?php
    require_once 'config.php';

    session_status() === PHP_SESSION_ACTIVE ? TRUE : session_start();

	class StudentCourseRegistrationController
	{

 		function __construct() {
			$this->objconfig = Config::getConnect('students');
			$this->objsm =  new StudentModel($this->objconfig);
			$this->objcm =  new CourseModel($this->objconfig);
		}

        // mvc handler request
		public function studentCourseHandler()	{
			$act = isset($_GET['act']) ? $_GET['act'] : NULL;
			switch ($act) {
			    case 'subscribe' :
			        $this->update();
			        break;
				default:
                    $this->list();
			}
		}

        public function list() {
            $data=$this->objsm->getSubscribeData();
            $studentResult=$this->objsm->getStudent(0);
            $students=mysqli_fetch_All($studentResult);
            $_SESSION['studentForSubscription']=serialize($students);
            $courseResult=$this->objcm->getCourse(0);
            $courses=mysqli_fetch_All($courseResult);
            $_SESSION['courseForSubscription']=serialize($courses);
            include "view/report.php";
        }

        public function update() {
            try {
                if (isset($_POST['subscribe'])) {
                    $student['id'] = trim($_POST['studentId']);
                    $student['courseSubscribeId']  = implode(',',$_POST['courseSubscribeId']);
                    $res = $this->objsm->updateStudent(null,$student['courseSubscribeId'],$student['id']);
                    if ($res) {
                        $this->list();
                        $this->pageRedirect("index.php");
                    } else {
                        echo "Somthing is wrong..., try again.";
                    }
                } else {
                   header('Location:view/student_course_registration.php');
                }
            }
            catch (Exception $e) {
                $this->close_db();
                throw $e;
            }
        }

        public function pageRedirect($url) {
            header('Location:'.$url);
        }
    }


?>
