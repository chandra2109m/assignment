<?php
    require 'model/CourseModel.php';
    require 'model/Course.php';
    require_once 'config.php';

    session_status() === PHP_SESSION_ACTIVE ? TRUE : session_start();

	class CourseController
	{

 		function __construct()
		{
			$this->objconfig = Config::getConnect('students');
			$this->objsm =  new CourseModel($this->objconfig);
		}
        // mvc handler request
		public function courseHandler()
		{
			$act = isset($_GET['act']) ? $_GET['act'] : NULL;
			switch ($act)
			{
                case 'courseAdd' :
					$this->insert();
					break;
				case 'courseUpdate':
					$this->update();
					break;
				case 'courseDelete' :
					$this -> delete();
					break;
				default:
                    $this->list();
			}
		}
        // page redirection
		public function pageRedirect($url)
		{
			header('Location:'.$url);exit();
		}

        // add new record
		public function insert()
		{
            try{
                $course=new Course();
                if (isset($_POST['addbtn']))
                {
                    // read form value
                    $course->courseName = trim($_POST['courseName']);
                    $course->courseDetails = trim($_POST['courseDetails']);
                    if($this->objsm->getCourse('',$course->courseName)->num_rows > 0) {
                         $_SESSION['error']='data already exist with this CourseName';
                         $this->pageRedirect("view/course_add.php");

                    } else {
                        if(isset($_SESSION['error']) && !empty($_SESSION['error'])){
                            session_unset();
                        }
                    }
                    $pid = $this->objsm->insertCourse($course);
                    if($pid>0){
                        $this->list();
                    } else {
                        echo "Somthing is wrong..., try again.";
                    }
                } else {
                    $_SESSION['sporttbl0']=serialize($course);//add session obj
                    $this->pageRedirect("view/course_add.php");
                }
            } catch (Exception $e) {
                $this->close_db();
                throw $e;
            }
        }

        // update record
        public function update() {
            try {
                if (isset($_POST['updatebtn'])) {
                    $course=unserialize($_SESSION['sporttbl0']);
                    $course->id = trim($_POST['id']);
                    $course->courseName = trim($_POST['courseName']);
                    $course->courseDetails = trim($_POST['courseDetails']);
                    if($this->objsm->getCourse('',$course->courseName)->num_rows > 0) {
                         $_SESSION['errorOnUpdate']='data already exist with this CourseName';
                         $this->pageRedirect("index.php?act=courseUpdate&id=".$course->id);
                    } else {
                        if(isset($_SESSION['errorOnUpdate']) && !empty($_SESSION['errorOnUpdate'])){
                            session_unset();
                        }
                    }
                    $res = $this->objsm->updateCourse($course);
                    if ($res) {
                        $this->list();
                    } else {
                        echo "Somthing is wrong..., try again.";
                    }
                }
                elseif (isset($_GET["id"]) && !empty(trim($_GET["id"]))) {
                    $id=$_GET['id'];
                    $result=$this->objsm->getCourse($id);
                    $row=mysqli_fetch_array($result);
                    $course=new Course();
                    $course->id=$row["id"];
                    $course->courseName=$row["courseName"];
                    $course->courseDetails=$row["courseDetails"];
                    $_SESSION['sporttbl0']=serialize($course);
                    $this->pageRedirect('view/course_update.php');
                } else {
                    echo "Invalid operation.";
                }
            }
            catch (Exception $e) {
                $this->close_db();
                throw $e;
            }
        }
        // delete record
        public function delete()
		{
            try {
                if (isset($_GET['id'])) {
                    $id=$_GET['id'];
                    $res=$this->objsm->deleteCourse($id);
                    if ($res) {
                        $this->pageRedirect('index.php');
                    } else {
                        echo "Somthing is wrong..., try again.";
                    }
                } else {
                    echo "Invalid operation.";
                }
            }
            catch (Exception $e) {
                $this->close_db();
                throw $e;
            }
        }

        //list record
        public function list() {
            $result=$this->objsm->getCourse(0);
            include "view/course_list.php";
        }
    }


?>
