<?php
    require 'model/StudentModel.php';
    require 'model/student.php';
    require_once 'config.php';

    session_status() === PHP_SESSION_ACTIVE ? TRUE : session_start();

	class StudentController
	{

 		function __construct() {
			$this->objconfig = Config::getConnect('students');
			$this->objsm =  new StudentModel($this->objconfig);
			$_SESSION['token'] = md5(uniqid(mt_rand(), true));
		}

        // mvc handler request
		public function studentHandler() {
			$act = isset($_GET['act']) ? $_GET['act'] : NULL;
			switch ($act) {
                case 'add' :
					$this->insert();
					break;
				case 'update':
					$this->update();
					break;
				case 'delete' :
					$this->delete();
					break;
				default:
                    $this->list();
			}
		}

        // page redirection
		public function pageRedirect($url) {
			header('Location:'.$url);
		}

        // add new record
		public function insert() {
            try {
                $student=new Student();
                if (isset($_POST['addbtn'])) {
                     if ($_POST['token']) {
                        $this->csrfCheck();
                     }
                    // read form value
                    $student->firstName = trim($_POST['firstName']);
                    $student->lastName = trim($_POST['lastName']);
                    $student->contactNo = trim($_POST['contactNo']);
                    $student->dob = trim($_POST['dob']);
                    $pid = $this->objsm->insertStudent($student);
                    if($pid>0){
                        $this->list();
                        $this->pageRedirect("index.php");
                    }else{
                        echo "Somthing is wrong..., try again.";
                    }
                } else {
                        $_SESSION['sporttbl0']=serialize($student);//add session obj
                        $this->pageRedirect("view/student_add.php");
                    }
            } catch (Exception $e) {
                $this->close_db();
                throw $e;
            }
        }
        // update record
        public function update() {
            try {
                if (isset($_POST['updatebtn'])) {
                    if ($_POST['token']) {
                        $this->csrfCheck();
                    }
                    $student=unserialize($_SESSION['sporttbl0']);
                    $student->id = trim($_POST['id']);
                    $student->firstName = trim($_POST['firstName']);
                    $student->lastName = trim($_POST['lastName']);
                    $res = $this->objsm->updateStudent($student);
                    if($res){
                        $this->list();
                        $this->pageRedirect("index.php");
                    }else{
                        echo "Somthing is wrong..., try again.";
                    }
                } elseif (isset($_GET["id"]) && !empty(trim($_GET["id"]))) {
                    $id=$_GET['id'];
                    $result=$this->objsm->getStudent($id);
                    $row=mysqli_fetch_array($result);
                    $student=new Student();
                    $student->id=$row["id"];
                    $student->firstName=$row["firstName"];
                    $student->lastName=$row["lastName"];
                    $_SESSION['sporttbl0']=serialize($student);
                    $this->pageRedirect('view/student_update.php');
                } else {
                    echo "Invalid operation.";
                }
            }
            catch (Exception $e)
            {
                $this->close_db();
                throw $e;
            }
        }
        // delete record
        public function delete()
		{
            try
            {
                if (isset($_GET['id']))
                {
                    $id=$_GET['id'];
                    $res=$this->objsm->deleteStudent($id);
                    if($res){
                        $this->pageRedirect('index.php');
                    }else{
                        echo "Somthing is wrong..., try again.";
                    }
                }else{
                    echo "Invalid operation.";
                }
            }
            catch (Exception $e)
            {
                $this->close_db();
                throw $e;
            }
        }

        public function list(){
            $result=$this->objsm->getStudent(0);
            include "view/student_list.php";
        }

        public function csrfCheck(){
            $token = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_STRING);
            if (!$token || $token !== $_SESSION['token']) {
                // show an error message
                echo '<p class="error" style="color:red">Error: invalid form submission</p>';
                // return 405 http status code
                header($_SERVER['SERVER_PROTOCOL'] . ' 405 Method Not Allowed');
            }
        }
    }


?>
